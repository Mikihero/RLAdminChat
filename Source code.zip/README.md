# RLAdminChat
RLAdminChat is an SCP:SL plugin that sends a message in AdminChat whenever Roundlock is toggled.
The entire purpose of this plugin is to allow for easier coordination of event organization between server administrators.
By using this plugin you can remove a lot of confusion that happens when few people at once toggle Roundlock during an event.
This plugin is property of Miki_hero. If you want to use it contact me on Discord (Miki_hero#6969).