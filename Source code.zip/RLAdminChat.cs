﻿using Exiled.API.Features;
using Exiled.API.Enums;
using System;
using System.Timers;

namespace RLAdminChat
{
    public class RLAdminChat : Plugin<Config>
    {
        private static System.Timers.Timer aTimer;

        private static readonly Lazy<RLAdminChat> LazyInstance = new Lazy<RLAdminChat>(() => new RLAdminChat());
        public static RLAdminChat Instance => LazyInstance.Value;

        public override PluginPriority Priority { get; } = PluginPriority.Medium;


        private RLAdminChat()
        {
            
        }
        public static int tester1 = 2;
        public static int tester2 = 2;
        public static void RoundLockAdminChat(Object sender, ElapsedEventArgs e)
        {
            if(Round.IsLocked == true)
            {
                string message = RLAdminChat.Instance.Config.RLEnabledMessage;
                tester1 = 1;
                if (tester2 == 2)
                {
                    tester2 = tester1;
                    Map.Broadcast(2, message, Broadcast.BroadcastFlags.AdminChat);
                }
                    
                if (tester2 == tester1)
                {
                    
                }
                else
                {
                    Map.Broadcast(2, message, Broadcast.BroadcastFlags.AdminChat);
                    tester2 = tester1;
                }
            }
            else
            {
                string message = RLAdminChat.Instance.Config.RLDisabledMessage;
                tester1 = 0;
                if (tester2 == 2)
                {
                    tester2 = tester1;
                    Map.Broadcast(2, message, Broadcast.BroadcastFlags.AdminChat);
                }
                if (tester2 == tester1)
                {
                    
                }
                else
                {
                    Map.Broadcast(2, message, Broadcast.BroadcastFlags.AdminChat);
                    tester2 = tester1;
                }
            }
        }

        private static void SetTimer()
        {
            aTimer = new System.Timers.Timer(1000); 
            aTimer.Elapsed += RoundLockAdminChat;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        public override void OnEnabled()
        {
            SetTimer();

        }
    }
}
