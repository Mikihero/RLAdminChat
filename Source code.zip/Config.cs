﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exiled.API.Interfaces;
using System.ComponentModel;

namespace RLAdminChat
{
    public sealed class Config : IConfig
    {
        [Description("Enable or disable the plugin.")]
        public bool IsEnabled { get; set; } = true;

        [Description("The message sent when someone enables the RoundLock, can't be colored since it's sent through admin chat.")]
        public string RLEnabledMessage { get; set; } = "[RLAdminChat] RoundLock has been enabled.";

        [Description("The message sent when someone disables the RoundLock, can't be colored since it's sent through admin chat.")]
        public string RLDisabledMessage { get; set; } = "[RLAdminChat] RoundLock has been disabled.";
    }
}
